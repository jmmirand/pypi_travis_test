
class Calculadora:


    def suma( self, a , b):
        return a + b


    def resta (self, a  , b ):
        return (a - b)


    def por (self, a, b ):
        return ( a * b )